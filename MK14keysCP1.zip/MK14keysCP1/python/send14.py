#!/usr/bin/env python3

#---------------------------------------------------------------------------------------------------
#
# Read in a named Intel Hex file and send it to an MK14 via Arduino serial port
# adapted from send14 by SiriusHardware on https://www.vintage-radio.net
# you may need to adjust the serial port depending upon your setup
#
# V1.1: Bug fixed, Intel Hex lines with a '00' checksum byte would not load - SH
#
# V1.2: Bug fixed, where an execution address was found at FFFE/FFFF in file,
# uploader was (unintentionally) also typing the program execution address into 
# 0FFE/0FFF, disrupting the state of the hardware flag outputs - SH
#
#---------------------------------------------------------------------------------------------------

import sys
import os.path
import time
import serial

# define the Serial port to use
# on Linux you can check sudo dmesg after connecting the arduino
# or check ls /dev/tty*

#SerialPort = 'com4'		# windows style
SerialPort = '/dev/ttyUSB0'  # linux style Arduino Nano 
#SerialPort = '/dev/ttyACM0'  #  linux style Arduino UNO

# If your MK14 has the 'Old' OS with the "---- --" reset prompt, edit
# the line below to read 'MK14_OS = 0'

MK14_OS = 1

# The following delay values may need to be played with (increased)
# if these values do not give reliable error free input.

# Minimum length of a keypress (seconds).
KeyPressLength=0.01
# Time for post-release debounce delay (seconds).
KeyReleaseLength=0.01
# Additional settle time after entry mode change (seconds).
ModeChangeSettleTime=0.06

#---------------------------------------------------------------------------------------------------
# Function: Send the character to be 'typed' across to the Arduino
# via the serial link
#---------------------------------------------------------------------------------------------------

def Push(key):

    print(b'Sending ' + key)

    ser.write(key)	# send the line to the arduino
    time.sleep(KeyPressLength)
    time.sleep(KeyReleaseLength)

#---------------------------------------------------------------------------------------------------
# Function: Convert characters 0-9,A-F and the command keys g-m-a-t and 'r'
# 'r' to key characters to be sent to the Arduino
#
#---------------------------------------------------------------------------------------------------

def Press_MK14_Key(key):
    if key=="t":          # Term
        Push(b't')
    elif key=="m":        # Mem
        Push(b'm')
    elif key=="0":
        Push(b'0')
    elif key=="1":
        Push(b'1')
    elif key=="2":
        Push(b'2')
    elif key=="3":
        Push(b'3')
    elif key=="4":
        Push(b'4')
    elif key=="5":
        Push(b'5')
    elif key=="6":
        Push(b'6')
    elif key=="7":
        Push(b'7')
    elif key=="8":
        Push(b'8')
    elif key=="9":
        Push(b'9')
    elif key=="A":
        Push(b'a')
    elif key=="B":
        Push(b'b')
    elif key=="C":
        Push(b'c')
    elif key=="D":
        Push(b'd')
    elif key=="E":
        Push(b'e')
    elif key=="F":
        Push(b'f')
    elif key=="g":          # Go
        Push(b'g')
    elif key=="a":          # Abort
        Push(b'q')
    elif key=="r":          # System Reset
        Push(b'r')
        time.sleep(0.06)    # Allow MK14 time to come back up after Reset 
        time.sleep(1)

    bytesToRead = ser.inWaiting()
    if (bytesToRead > 0):
        print( ser.read(bytesToRead))


#---------------------------------------------------------------------------------------------------
# Function: Read Intel Hex file, send to MK14 as keypresses
#---------------------------------------------------------------------------------------------------

def SendFileToMK14(FileName):

    # Try to reset the MK14 before sending the file

    print ("Resetting...")
    bytesToRead = ser.inWaiting()
    if (bytesToRead > 0):
        print( ser.read(bytesToRead))

    # try reset a number of times as not always successful when program is running
    Press_MK14_Key("r")
    Press_MK14_Key("r")
    Press_MK14_Key("r")
    print ("waiting for reset to complete")
    time.sleep(3)       # wait 3 seconds

    # Assume by default that this file does not contain an execution
    # address at FFFE unless we find otherwise.
    ExecuteFlag=0

    # Initially no errors have occurred. This flag will be set to 1
    # If an error occurs during the load process
    ErrorFlag=0

    # Open the file
    with open(FileName) as fileobj:

        # While there are lines to read from the file, read a line

        AddressAsHex="" # Hex string copy of most recent address incremented to. Empty on first pass.

        print ("Sending... ")

        for line in fileobj:

           # Check for Intel Hex Line start character
           # If not, declare file invalid and exit

           if (line [0]!=":"):
                ErrorFlag=1
                print ("Invalid Hex File")
                break
           else:
                # Read this line's 'record type',
                # If it is not a normal record (00), don't do anything with the line

                RecordTypeString=line[7:9]
                if (RecordTypeString=="00"):


                   # ..A normal record, so proceed to scan the line
                   # Zero the calculated line checksum

                   ChkSum=0

                   # By default, send whatever is read from the line to the
                   # MK14. This can be overridden with OutputMode = 0 if we only
                   # want to read and checksum the line, and not send it.

                   OutputMode=1

                   #Convert the record type to raw and add it to the calculated checksum

                   RecordTypeRaw=int(RecordTypeString, 16)
                   ChkSum=ChkSum+RecordTypeRaw

                   # Get the number of data bytes this line holds,
                   # convert to raw value and add to checksum.

                   DataBytesCountString=line[1:3]
                   DataBytesCount=int(DataBytesCountString,16)
                   ChkSum=ChkSum+DataBytesCount

                   # Get the four address digits, convert to raw 4 digit
                   # address, used as address upcounter.

                   AddressDigitsString=line[3:7]
                   AddressDigitsRaw=int(AddressDigitsString,16)

                   # Get the hi byte (only) of the address,
                   # add its byte value to the checksum.

                   AddressDigitsHiString=AddressDigitsString[0:2]
                   AddressDigitsHiRaw=int(AddressDigitsHiString,16)
                   ChkSum=ChkSum+AddressDigitsHiRaw

                   # Get the lo byte (only) of the address,
                   # add its byte value to the checksum.

                   AddressDigitsLoString=AddressDigitsString[2:4]
                   AddressDigitsLoRaw=int(AddressDigitsLoString,16)
                   ChkSum=ChkSum+AddressDigitsLoRaw

                   # If the start address of this line does not follow
                   # on consecutively from the last address in the previous
                   # line, First check if it is = 0xFFFE. If so, harvest the
                   # execution address but do not output the rest of the
                   # line. If not, go to address entry mode, enter
                   # the new address, then return to data entry mode and
                   # carry on sending data to the new address onwards.

                   if (AddressDigitsString!=AddressAsHex):
                   # Further check: If the start address of this line is
                   # FFFE = a 'run address' line...
                       if (AddressDigitsString=="FFFE") & (DataBytesCount>1):
                           ExecutionAddressHiString=line[9:11]
                           ExecutionAddressLoString=line[11:13]
                           ExecuteFlag=1 # Execution address was found
                           OutputMode=0 # Validate line but do not send it

                       else:
                           # Change to address entry mode. Key depends on
                           # whether the OS is old or new version.
                           if MK14_OS!=1:
                               Press_MK14_Key('m')  # Old OS: Press Mem
                           else:
                               Press_MK14_Key('a')  # New OS: Press Abort

                           # Allow settle time after mode change
                           time.sleep(ModeChangeSettleTime)

                           Press_MK14_Key(AddressDigitsHiString[0])
                           Press_MK14_Key(AddressDigitsHiString[1])
                           Press_MK14_Key(AddressDigitsLoString[0])
                           Press_MK14_Key(AddressDigitsLoString[1])

                           #Change to data entry mode
                           Press_MK14_Key('t')  # Press Term

		                   # Allow settle time after mode change
                           time.sleep(ModeChangeSettleTime)

                   # Scan and output the data bytes as MSD and LSD and
                   # add the byte value of the databyte to the checksum

                   for x in range (9,(9+DataBytesCount*2),2):
                       DataByteString=line[x:x+2]
                       DataByteRaw=int(DataByteString,16)
                       ChkSum=ChkSum+DataByteRaw

                       if (OutputMode==1):
                           #Output the high and low digits of the databyte
                           Press_MK14_Key(DataByteString[0])
                           Press_MK14_Key(DataByteString[1])

                           # On New OS only a single 'MEM' press is required
                           # to enter data / advance address. On Old OS,
                           # Term-Mem-Term sequence is required for each
                           # data byte entry / address advance.

                           if MK14_OS !=1:
                               Press_MK14_Key('t')  # Press Term

                           Press_MK14_Key('m')  # Press Mem

                           if MK14_OS !=1:
                               Press_MK14_Key('t') # Press Term

                       #advance the raw address keeper
                       AddressDigitsRaw=AddressDigitsRaw+1
                       # AddressAsHex = ASCII hex version of current address
                       AddressAsHex="%0.4X" % AddressDigitsRaw


                   # Get the line's checksum from the end of the line
                   LineChecksumString=line[(9+(DataBytesCount*2)):(9+(DataBytesCount*2)+2)]

                   # Calculated checksum has to be converted to its 8-bit twos-
                   # complement before comparison with the file checksum

                   # Invert it
                   ChkSum=~ChkSum

                   # Add one to it
                   ChkSum=ChkSum+1

                   # Strip it back down to one byte
                   ChkSum=ChkSum & 255

                   # Convert it to hex string
                   ChkSumHexString = "%0.2X" % ChkSum

                   # Check whether it is valid, if not, abort
                   if LineChecksumString!=ChkSumHexString:
                       print ("Invalid Checksum in file.")
                       print (line)
                       print (LineChecksumString)
                       print (ChkSumHexString)

                       ErrorFlag=1
                       break

        # When all lines have been processed, exit data entry mode.
        Press_MK14_Key('a')
        time.sleep(ModeChangeSettleTime)

        # If an execution address was found in the file at special address FFFE and
        # there were no errors during the load process, execute froom that address.
        # Key sequence depends on OS version.

        if (ExecuteFlag==1) & (ErrorFlag==0):

            if MK14_OS !=1:
                Press_MK14_Key('g')

            Press_MK14_Key (ExecutionAddressHiString[0])
            Press_MK14_Key (ExecutionAddressHiString[1])
            Press_MK14_Key (ExecutionAddressLoString[0])
            Press_MK14_Key (ExecutionAddressLoString[1])

            if MK14_OS !=1:
                Press_MK14_Key ('t')
            else:
                Press_MK14_Key ('g')

            print ("Executing...")

        if ErrorFlag==0:
            print ("Done.")
        else:
            print ("Aborted.")

#---------------------------------------------------------------------------------------------------
# Main Body Of Program
#---------------------------------------------------------------------------------------------------

# Initialise
# sets serial port
print("Opening Serial port ")
ser = serial.Serial(SerialPort, 9600, stopbits=2 )

# need to wait for the arduino to reset as activating the serial port can reset the Arduino
time.sleep(5)

# Pull the filename from the argument supplied.
# Filename of hex file must include extension and
# is case-sensitive.


# If the user has supplied a filename, the second element
# of sys.argv contains the filename. If there is no second
# element, the user did not supply a filename.

if len ((sys.argv))>1:
    FileName=(sys.argv[1])

    # If the file exists, send the contents to the MK14
    if os.path.exists(FileName):
        SendFileToMK14(FileName)

    # If not, abort.
    else:
        print ("File not found...")
        print ("Aborted.")

# The user did not supply a filename.
else:
    print("Please supply a hex file name...")
    print("Aborted.")

# end of code

